const images = {
    logo: require('~/assets/images/logo.png'),
    noImage: require('~/assets/images/no-image.png'),
};
export default images;
